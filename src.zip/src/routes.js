import React from 'react';
import {createAppContainer,createSwitchNavigator} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
import Login from './screens/Login';
import Home from './screens/Home';
import AddUser from './screens/Adduser';
import  AuthLoadingScreen from './screens/AuthLoadingScreen'
const defaultStackNavOptions = {
  headerStyle: {
    backgroundColor: '#008000',
  },
  headerTintColor: 'white',
  headerTitleSyle: {
    fontFamily: 'open-sans-bold',
  },
  headerBackTitleStyle: {
    fontFamily: 'open-sans',
  },
};
// const routes = createStackNavigator(
//     {
//       Adduser: AddUser,
//       Welcome: Login,
//       ListScreen: Home,
//     },   
//   );
  const routes = createStackNavigator(
    {
      ListScreen:Home,
      Adduser:AddUser
      
    },
    {
      defaultNavigationOptions: defaultStackNavOptions,
    },
  );
  const AuthStack = createStackNavigator(
    {
    Welcome: Login,
    
    },
    {
      defaultNavigationOptions: defaultStackNavOptions,
    },
  );
  const SwitchNavigator = createSwitchNavigator(
    {
      AuthLoading: AuthLoadingScreen,
      App: routes,
      Auth: AuthStack,
    },
    {
      initialRouteName: 'AuthLoading',
    },
  );
  
export default createAppContainer(SwitchNavigator);