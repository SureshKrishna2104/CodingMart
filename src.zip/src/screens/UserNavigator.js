import React, {useEffect} from 'react';
import {
  View,
  Text,
  StyleSheet,
  Button,
  Platform,
  FlatList,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Modal,
  ScrollView,
  SafeAreaView,
  Alert,
} from 'react-native';
//import {AsyncStorage} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {createAppContainer, createSwitchNavigator} from 'react-navigation';
import {createStackNavigator} from 'react-navigation-stack';
import {createDrawerNavigator} from 'react-navigation-drawer';
import Login from '../screens/Login';
import SignUp from '../screens/SignUp';
import Home from '../screens/Home';
import DashBoard from '../screens/DashBoard';
import DashBoardDetails from '../screens/DashBoardDetails';
import AuthLoadingScreen from '../screens/AuthLoadingScreen';
import ChatScreen from '../screens/ChatScreen';
import UserDetail from '../screens/UserDetail';
import EditUserDetail from '../screens/EditUserDetail';

// //const value = AsyncStorage.getItem('userInfo');
// console.warn('value', value);
const defaultStackNavOptions = {
  headerStyle: {
    backgroundColor: '#0f73ee',
  },
  headerTintColor: 'white',
  headerTitleSyle: {
    fontFamily: 'open-sans-bold',
  },
  headerBackTitleStyle: {
    fontFamily: 'open-sans',
  },
};

const UserNavigator = createStackNavigator(
  {
    dashboard: DashBoard,
    dashboarddetail: DashBoardDetails,
    signup: SignUp,
    home: Home,
    login: Login,
    chat: ChatScreen,
    userdetail: UserDetail,
    edituser: EditUserDetail,
  },
  {
    defaultNavigationOptions: defaultStackNavOptions,
  },
);
const AuthStack = createStackNavigator(
  {
    login: Login,
    signup: SignUp,
  },
  {
    defaultNavigationOptions: defaultStackNavOptions,
  },
);
const SwitchNavigator = createSwitchNavigator(
  {
    AuthLoading: AuthLoadingScreen,
    App: UserNavigator,
    Auth: AuthStack,
  },
  {
    initialRouteName: 'AuthLoading',
  },
);
const MainNavigator = createDrawerNavigator(
  {
    MainPage: {
      screen: SwitchNavigator,
      navigationOptions: {
        drawerLabel: 'Home',
      },
    },
  },
  {
    contentComponent: props => (
      <View style={{flex: 1}}>
        <SafeAreaView forceInset={{top: 'always', horizontal: 'never'}}>
          <TouchableOpacity
            onPress={() =>
              Alert.alert(
                'Log out',
                'Do you want to logout?',
                [
                  {
                    text: 'Cancel',
                    onPress: () => {
                      return null;
                    },
                  },
                  {
                    text: 'Confirm',
                    onPress: () => {
                      //AsyncStorage.clear();
                      AsyncStorage.removeItem('userInfo');
                      props.navigation.navigate('AuthLoading');
                    },
                  },
                ],
                {cancelable: false},
              )
            }>
            <Text style={{margin: 16, fontWeight: 'bold', color: 'red'}}>
              Logout
            </Text>
          </TouchableOpacity>
        </SafeAreaView>
      </View>
    ),
    drawerOpenRoute: 'DrawerOpen',
    drawerCloseRoute: 'DrawerClose',
    drawerToggleRoute: 'DrawerToggle',
  },
);

export default createAppContainer(MainNavigator);
