import React,{useState,useEffect} from 'react';
import { Text, View,StyleSheet, TouchableOpacity, Touchable , AsyncStorage} from 'react-native';
import AntDesign from 'react-native-vector-icons/AntDesign';
import CommonStyles from '../constants/styles';
import { getAllData } from '../services/Apiservices';

const Home = ({ navigation }) => {
  const [data,setData] = React.useState([])
  const[jwt,setJwt]=React.useState('')
  useEffect(() => {
    AsyncStorage.getItem('userInfo').then(async (res) => {
      const jwt = await res;
      setJwt(jwt)
      console.log(jwt)
      getAllData('getAllUser/0/5', jwt)
                .then((response) => {
                    if (response.status == 200) {
                      console.log("Response",response);
                        //setLocation(response.data)
                        //copyArray(response.data)
                        //setIsLoading(false)
                        //console.log('location', JSON.stringify(response.data[0].city[0].cityName))
                        // setNewState(response.data[0].stateName)
                        // setNewCity(response.data[0].city[0].cityName)
                        // setStateData(response.data.city)
                        // setBooth(response.data.city.booth)
                    } else {
                        //setIsLoading(false)
                        console.log("Response",response);

                    }
                })
                .catch((error) => {
                    //setIsLoading(false)
                    console.log("Error",error);

                })
      });
  },[])
  return (
    <View style={styles.container}>
    <Text>{"\n"}</Text>
    <Text styles={styles.header}> List User</Text>
    <TouchableOpacity style={styles.fabContainer} onPress={() => navigation.navigate('Adduser')} >
    <AntDesign name='addusergroup' size={30} color={'#fff'} backgroundColor={'#008000'} />
    </TouchableOpacity>      
    </View>
  )
}
export default Home;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    header: {
      fontSize: 30,
      color: '#0f73ee',
      paddingBottom: 5,
      marginBottom: 20,
      paddingLeft: 60,
  },
    fabContainer: {
      flex: 1,
      borderRadius: 60,
      elevation: 5,
      padding: 20,
      backgroundColor: '#008000',
      position: 'absolute',
      bottom: 40,
      right: 10
  },
});