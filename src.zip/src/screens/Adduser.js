import React from 'react';
import { Text, View,StyleSheet, TouchableOpacity, Touchable, ScrollView, TextInput } from 'react-native';

const AddUser = ({ navigation }) => {
    const [userData, setUserData] = React.useState({
        firstName: '',
        lastName: '',
        designation: '',
        phoneNumber: '',
        alternatePhone: '',
        email: '',
        alternatePhone: '',
        company: '',
        company_address1: '',
        company_address2: '',
        state: '',
        district: '',
        street: '',
        city: '',
        country: '',
        location: '',
        pincode: '',
        region: '',
        product: [],        
    });
  return (
    <ScrollView>
        <View style={styles.regform}> 
        <View style={styles.textInputContainer}>
            <Text style={styles.textcolor}>First Name <Text style={{ color: 'red', fontSize: 16 }}>*</Text> </Text>
            <TextInput style={styles.textinput}
            placeholder="Enter your First name" underlineColorAndroid={'transparent'}
            onChangeText={(text) => setUserData({'firstName':text})}
            />
        </View>
        <View style={styles.textInputContainer}>
            <Text style={styles.textcolor}>Last Name <Text style={{ color: 'red', fontSize: 16 }}>*</Text> </Text>
            <TextInput style={styles.textinput}
            placeholder="Enter your Last name" underlineColorAndroid={'transparent'}
            onChangeText={(text) => setFName(text)}
            />
        </View>
        <View style={styles.textInputContainer}>
            <Text style={styles.textcolor}>First Name <Text style={{ color: 'red', fontSize: 16 }}>*</Text> </Text>
            <TextInput style={styles.textinput}
            placeholder="Enter your First name" underlineColorAndroid={'transparent'}
            onChangeText={(text) => setFName(text)}
            />
        </View>
        </View>
        </ScrollView>
  )
}
export default AddUser;
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
    },
    textInputContainer: {
        padding: 3,
        justifyContent: 'flex-start'
    },
    textcolor: {
        fontSize: 12,
        marginTop: 5,
        color: '#808080',
    },
    textinput: {
        borderWidth: 1,
        fontSize: 14,
        paddingLeft: 10,
        color: 'black',
        borderColor: '#A9A9A9',
    },
});