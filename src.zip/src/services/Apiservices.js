export const URL = 'http://34.122.248.250:8080';

//export const jwt='eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJib290aG1lbWJlcjEiLCJleHAiOjE2MDcxODU0NDcsImlhdCI6MTYwNzE0OTQ0N30.kGIJemszMQh4t3Lr1znEDE5Os9_4OLvO5Py77sxtI20'

export const postMethod = (type, value) => {
    console.warn("Login", value);
    let data = {
      method: 'POST',
      credentials: 'same-origin',
      mode: 'same-origin',
      body: JSON.stringify(value),
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      }
    }
    return fetch(URL + type, data)
      .then(response => response.json())
      .then((responseData) => {
        console.warn('out of the', responseData);
        return responseData;
      });// promise
  }
  export const getAllData = (type,jwt_token) => {
    console.warn('jwt',type,jwt_token);
    let data = {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'Authorization':`Bearer ${jwt_token}`,
      }
    }
    console.log("url,",URL + type, data)
    return fetch(URL + type, data)
      .then((response) =>
      
      
      {
             console.log("res",response)
        return response; });
  }